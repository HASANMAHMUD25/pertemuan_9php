<?php 
    // tangkap request static.php
    require_once 'static.php';

    // akses static member variable
    Matematika::$counter++;
    Matematika::$counter++;
    Matematika::naikanCounter();
    echo 'Counter Sekarang : '. Matematika::$counter;
    echo '<hr/>';

    // akses static member function 
    $x = Matematika::tambahkan(4,5);
    echo "4 + 5 = $x";
    echo '<hr/>';

    // akses constanta 
    echo 'Nilai PHI : '. Matematika::PHI;
    $luas_lingkaran = Matematika::luasLingkaran(8);
    echo '<br>Luas Lingkaran dengan Jari-jari 8 adalah : '. $luas_lingkaran;

?>