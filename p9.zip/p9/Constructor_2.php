<!DOCTYPE html>
<html>
<head>
    <title>Tabel Santri</title>
    <style>
        table {
            width: 50%;
            margin: 50px auto; 
            border-collapse: collapse;
        }

        th, td {
            border: 2px solid black; 
            padding: 9px;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php 
        // tangkap request Constructor_1.php
        require_once 'Constructor_1.php';

        $ns1 = new NilaiSantri('Fulan',70);
        $ns2 = new NilaiSantri('Badu',69);
        $ns3 = new NilaiSantri('Usro',85);
        $ns4 = new NilaiSantri('Jarwo',40);

        $ar_santri = [$ns1,$ns2,$ns3,$ns4];
    ?>
    <table>
        <thead>
            <tr>
                <th style="width: 2%;">No</th>
                <th style="width: 15%;">Nama</th>
                <th style="width: 5%;">Nilai</th>
                <th style="width: 15%;">Hasil</th>
            </tr>
        </thead>
        <tbody>
        <?php
            $nomor = 1;
            foreach ($ar_santri as $san) {
                echo '<tr>';
                echo '<td>' . $nomor . '</td>';
                echo '<td>' . $san->nama . '</td>';
                echo '<td>' . $san->nilai . '</td>';
                echo '<td>' . $san->gethasil() . '</td>';
                echo '</tr>';
                $nomor++;
            }
        ?>
        </tbody>
    </table>
</body>
</html>
